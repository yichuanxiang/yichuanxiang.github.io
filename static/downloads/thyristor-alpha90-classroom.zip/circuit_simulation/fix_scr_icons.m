% Repair only the six top-level SCR mask drawings, then render and save.
root=fileparts(mfilename('fullpath'));cd(root);
outdir=fullfile(root,'output');
mdl='thyristor_bridge_R_alpha90_clear';
modelFile=fullfile(root,[mdl '.slx']);
backupFile=fullfile(outdir,'clear_model_before_icon_refresh.slx');
if ~isfile(backupFile),copyfile(modelFile,backupFile);end
diary(fullfile(outdir,'scr_icon_fix.log'));
load_system(modelFile);
for v=1:6
    block=[mdl '/VT' int2str(v)];
    mask=Simulink.Mask.get(block);
    mask.IconUnits='normalized';
    mask.Display=scr_icon_display(v);
    set_param(block,'ShowName','off');
end
lastwarn('');
set_param(mdl,'SimulationCommand','update');
print(['-s' mdl],'-dpng','-r180',fullfile(outdir,'clear_bridge_circuit.png'));
[warningMessage,warningId]=lastwarn;
assert(~contains(warningMessage,'MaskDisplay'),'Mask icon still fails: %s',warningMessage);
save_system(mdl,modelFile);
fprintf('SIX_SCR_ICONS_UPDATED_AND_RENDERED\n');
if ~isempty(warningMessage),fprintf('Other warning %s: %s\n',warningId,warningMessage);end
diary off;
