% Show and run the readable circuit in the MATLAB desktop.
root=fileparts(mfilename('fullpath'));cd(root);
diary(fullfile(root,'output','open_clear_model.log'));
try
    mdl='thyristor_bridge_R_alpha90_clear';
    open_system(fullfile(root,[mdl '.slx']));
    set_param(mdl,'ZoomFactor','FitSystem');
    fprintf('CLEAR_DESKTOP_OPENED\n');
    clearCircuitOutput=sim(mdl);
    assignin('base','clearCircuitOutput',clearCircuitOutput);
    scopePath=[mdl '/Waveforms/Scope_voltage'];
    open_system(scopePath);
    fprintf('CLEAR_DESKTOP_SIMULATED_AND_SCOPE_OPENED\n');
    fid=fopen(fullfile(root,'output','clear_desktop_ready.txt'),'w');
    fprintf(fid,'Opened and ran %s\n',get_param(mdl,'FileName'));fclose(fid);
catch ex
    fprintf(2,'%s\n',getReport(ex,'extended','hyperlinks','off'));
end
diary off;
