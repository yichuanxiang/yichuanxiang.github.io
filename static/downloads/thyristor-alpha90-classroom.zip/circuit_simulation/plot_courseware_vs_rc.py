"""Analytical courseware convention compared with saved external-RC simulation.

The top curve is explicitly an analytical drawing, not a new circuit simulation.
It uses the courseware's displayed ud1=ud2=0 convention during all-off gaps.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output'
font = Path('C:/Windows/Fonts/msyh.ttc')
if font.is_file():
    fontManager.addfont(str(font))
family = FontProperties(fname=str(font)).get_name() if font.is_file() else 'DejaVu Sans'
plt.rcParams.update({'font.family': family,
                     'mathtext.fontset': 'stix', 'axes.unicode_minus': False,
                     'font.size': 13, 'svg.fonttype': 'path', 'pdf.fonttype': 42})
CYAN, RED, BLACK, BLUE = '#00AEDB', '#EE2222', '#161616', '#003C9E'
DASH = (0, (7, 5))
df = pd.read_csv(OUT / 'clear_model_sensor_data.csv')
x = (df.t.to_numpy() - .08) * 18000
Um = float(np.max(np.abs(df.ua)))
th = np.linspace(120, 480, 7201)
ua = np.sin(np.deg2rad(th))
ub = np.sin(np.deg2rad(th-120))
uc = np.sin(np.deg2rad(th+120))
ph = {'a': ua, 'b': ub, 'c': uc}
fig = plt.figure(figsize=(15, 8.5), facecolor='white')
fig.text(.065, .95, 'VT1 管压：课件理想约定与外接 RC 模型', size=22, color=BLUE)
fig.text(.065, .905, r'$u_{VT1}=u_a-u_{d1}$；两图相电压和相位相同。', size=15)

for row, yy in enumerate([.56, .13]):
    ax = fig.add_axes([.095, yy, .84, .285])
    ax.set(xlim=(120, 480), ylim=(-1.96, 1.96), xticks=[], yticks=[])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.annotate('', (487, 0), (118, 0), annotation_clip=False,
                arrowprops={'arrowstyle': '-|>', 'color': BLACK, 'lw': .8})
    ax.annotate('', (120, 1.93), (120, -1.9), annotation_clip=False,
                arrowprops={'arrowstyle': '-|>', 'color': BLACK, 'lw': .8})
    ax.text(115, -.12, '$O$', ha='right', va='top', size=20)
    ax.text(115, 1.62, r'$u_{VT1}$', ha='right', size=20)
    ax.text(486, -.07, r'$\omega t$', va='top', size=20)
    for p, q in [('a','b'), ('a','c'), ('b','c'), ('b','a'), ('c','a'), ('c','b')]:
        ax.plot(th, ph[p]-ph[q], color=BLACK, ls=DASH, lw=.7, alpha=.75)
    ax.plot(th, ua, color=RED, ls=DASH, lw=1.2)
    for edge in np.arange(120, 481, 60):
        ax.axvline(edge, color=BLACK, ls=DASH, lw=.65)
    if row == 0:
        # Conduction sequence: (VT1,VT6), (VT1,VT2), (VT3,VT2),
        # (VT3,VT4), (VT5,VT4), (VT5,VT6). Each conducts 30 degrees.
        prev = None
        for j, start in enumerate(range(120, 480, 30)):
            q = (th >= start) & (th <= start+30)
            xx = th[q]
            if j % 2:
                val = ua[q]
                label = '$u_a$'
            else:
                upper = ['a','a','b','b','c','c'][j//2]
                val = (ua-ph[upper])[q]
                label = '$0$' if upper == 'a' else f'$u_{{a{upper}}}$'
            if prev is not None:
                ax.plot([start,start], [prev,val[0]], color=CYAN, lw=2.6)
            ax.plot(xx, val, color=CYAN, lw=2.6, zorder=4)
            prev = val[-1]
            mid = start+15
            value = float(np.interp(mid, xx, val))
            offset = .27 if value >= 0 else -.32
            ax.text(mid, value+offset, label, color=BLUE, ha='center', va='center', size=16)
        title = r'按课件画法：全截止时 $u_{d1}=u_{d2}=0$（解析示意）'
        footer = r'全截止段：$u_{VT1}=u_a$，沿红色相电压曲线。'
    else:
        sel = (x >= 120) & (x <= 480)
        ax.plot(x[sel], df.uVT1.to_numpy()[sel]/Um, color=CYAN, lw=2.6, zorder=4)
        for start in range(150, 480, 60):
            mid = start+15
            value = float(np.interp(mid, x, df.uVT1/Um))
            ax.text(mid, value+(.32 if value >= 0 else -.32), r'$u_a-u_x$',
                    color=BLUE, ha='center', va='center', size=16)
        title = '此前的六条外接 RC 模型（已保存的电路仿真数据）'
        footer = r'全截止段：$u_{VT1}\approx u_a-u_x$；该模型中 $u_x\approx\pm\sqrt{2}U/2$。'
    fig.text(.095, yy+.318, title, size=16, color=BLUE)
    fig.text(.095, yy-.05, footer, size=14)

fig.text(.065, .025, '上图按课件约定补画；下图对应额外接入 RC 的电路。两者都不能直接称为实物测量波形。',
         size=12, color=BLACK)
for ext in ['png','svg','pdf']:
    fig.savefig(OUT / f'vt1_courseware_vs_externalRC.{ext}', dpi=170, facecolor='white')
plt.close(fig)
manifest = {'top': 'Analytical drawing using teacher fig3-26 ud1=ud2=0 gap convention; not simulation',
            'bottom': 'Previously saved native SCR simulation with six external RC branches',
            'bottomSource': 'output/clear_model_sensor_data.csv',
            'hardwareMeasured': False}
(OUT / 'courseware_vs_rc_scope.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print('Saved explicitly labelled analytical-vs-simulated comparison.')
