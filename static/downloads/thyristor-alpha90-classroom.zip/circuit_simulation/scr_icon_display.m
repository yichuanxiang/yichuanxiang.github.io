function displayCode=scr_icon_display(v)
% Generate complete mask commands without a second formatting pass.
validateattributes(v,{'numeric'},{'scalar','integer','>=',1,'<=',6});
commands={
    'color(''blue'');'
    'plot([0.5 0.5],[0.03 0.27]);'
    'plot([0.3 0.7 0.5 0.3],[0.28 0.28 0.66 0.28]);'
    'plot([0.28 0.72],[0.69 0.69]);'
    'plot([0.5 0.5],[0.69 0.98]);'
    'plot([0.08 0.36],[0.5 0.64]);'
    'text(0.69,0.48,''RC'');'
    ['text(0.64,0.86,''VT' int2str(v) ''');']
    'port_label(''LConn'',1,''A'');'
    'port_label(''RConn'',1,''K'');'
};
displayCode=strjoin(commands,newline);
end
