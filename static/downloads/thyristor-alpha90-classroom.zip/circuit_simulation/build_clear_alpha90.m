function build_clear_alpha90(doVerify)
% A readable, executable model using the original circuit's device parameters.
if nargin<1,doVerify=true;end
root=fileparts(mfilename('fullpath'));cd(root);outdir=fullfile(root,'output');
diary(fullfile(outdir,'clear_model_build.log'));
old='thyristor_bridge_R_alpha90';mdl='thyristor_bridge_R_alpha90_clear';
load_system(fullfile(root,[old '.slx']));
if bdIsLoaded(mdl),close_system(mdl,0);end
new_system(mdl);
for name={'Solver','SolverType','MaxStep','RelTol','AbsTol','StopTime'}
    set_param(mdl,name{1},get_param(old,name{1}));
end
set_param(mdl,'ReturnWorkspaceOutputs','on','SaveTime','on','SaveOutput','off', ...
    'InitFcn',"load(fullfile(fileparts(get_param(bdroot,'FileName')),'gate_inputs.mat'));Um=sqrt(2)*220;");
p=struct('UphaseRMS',220,'f',50,'Rload',10,'alpha',90,'Ron',0.001,'Vf',0.8,'Goff',1e-7,'Ih',0.1,'Rsnub',500,'Csnub',250e-9,'gateAmplitude',10,'pulseWidth',5,'stop',0.12);
set_param(mdl,'InitFcn',"load(fullfile(fileparts(get_param(bdroot,'FileName')),'gate_inputs.mat'));Um=sqrt(2)*220;");

% Three actual AC sources, their neutral and voltage probes inside one clean icon.
src=newSub(mdl,'Sources_ABC',[80 315 250 515]);
pn=conn(src,'N','Left',1,[40 325 60 345]);
ph=zeros(1,3);
for k=1:3
    y=70+(k-1)*110;
    ac=add_block(sprintf('%s/Source_%s',old,char('a'+k-1)), ...
        sprintf('%s/Source_%s',src,char('a'+k-1)),'Position',[165 y 205 y+55]);
    h=get_param(ac,'PortHandles');wire(src,h.RConn(1),pn);
    ph(k)=conn(src,char('a'+k-1),'Right',k+1,[470 y+10 490 y+30]);
    wire(src,h.LConn(1),ph(k));
    probe(src,h.LConn(1),pn,['u' char('a'+k-1)],[265 y]);
end
mask=Simulink.Mask.create(src);
mask.IconUnits='normalized';
mask.Display=sprintf(['color(''blue'');\n' ...
    'theta=linspace(0,2*pi,80);\n' ...
    'for yy=[0.25 0.5 0.75],plot(0.28+0.1*cos(theta),yy+0.07*sin(theta));' ...
    'plot(linspace(0.21,0.35,40),yy+0.03*sin(linspace(0,2*pi,40)));end\n' ...
    'text(0.65,0.58,''三相'');text(0.65,0.45,''交流电源'');\n' ...
    'port_label(''LConn'',1,''N'');port_label(''RConn'',1,''a'');' ...
    'port_label(''RConn'',2,''b'');port_label(''RConn'',3,''c'');']);
set_param(src,'ShowName','off');

% Separate controller uses named Simulink gate signals. Electrical wires remain physical.
gates=newSub(mdl,'Gate_Control',[80 120 250 240]);
for v=1:6
    y=40+v*55;
    g=add_block(sprintf('%s/Gate_VT%d',old,v),sprintf('%s/Gate_VT%d',gates,v), ...
        'Position',[40 y 145 y+30]);
    q=get_param(g,'PortHandles');
    tag=add_block('simulink/Signal Routing/Goto',sprintf('%s/G%d',gates,v), ...
        'GotoTag',sprintf('gate_VT%d',v),'TagVisibility','global', ...
        'Position',[205 y 280 y+25]);t=get_param(tag,'PortHandles');
    add_line(gates,q.Outport(1),t.Inport(1),'autorouting','on');
    ws=add_block('simulink/Sinks/To Workspace',sprintf('%s/gVT%d_log',gates,v), ...
        'VariableName',sprintf('gVT%d',v),'SaveFormat','Timeseries', ...
        'Position',[345 y 440 y+30]);w=get_param(ws,'PortHandles');
    add_line(gates,q.Outport(1),w.Inport(1),'autorouting','on');
end
mask=Simulink.Mask.create(gates);
mask.IconUnits='normalized';
mask.Display='color(''black'');text(0.18,0.74,''门极触发'');text(0.25,0.49,''α = 90°'');text(0.12,0.25,''双窄脉冲'');';
set_param(gates,'BackgroundColor','yellow','ShowName','off');

% A and K have physical connector ports; RC, branch-current probe and gate input
% remain actual blocks within each SCR cell, not a synthesized voltage source.
columns=[440 690 940];ups=[1 3 5];downs=[4 6 2];cells=zeros(1,6);
for k=1:3
    x=columns(k);
    cells(ups(k))=makeSCR(mdl,old,ups(k),[x-55 265 x+55 355]);
    cells(downs(k))=makeSCR(mdl,old,downs(k),[x-55 480 x+55 570]);
end
% Load is a physical resistor. Its orientation puts its terminals above/below.
r=add_block([old '/R_load'],[mdl '/R_load'], ...
    'Position',[1130 380 1180 455],'Orientation','down');rh=get_param(r,'PortHandles');
d1=rh.LConn(1);d2=rh.RConn(1);
sh=get_param(src,'PortHandles');
fprintf('SOURCE PORTS L=%d R=%d\n',numel(sh.LConn),numel(sh.RConn));
assert(numel(sh.LConn)==1 && numel(sh.RConn)==3,'Unexpected source connector numbering.');
% Only N is grounded. Bring it around the bottom, clearly separate from d2.
ref=add_block([old '/Neutral_reference'],[mdl '/N_reference'], ...
    'Position',[100 655 135 680]);fh=get_param(ref,'PortHandles');N=fh.LConn(1);
sol=add_block([old '/Solver'],[mdl '/Solver'], ...
    'Position',[20 620 80 650]);

% Two readable d1/d2-to-N probes, with hidden signal logging inside their icons.
pd1=makeProbe(mdl,'Measure_d1','ud1',[1320 235 1400 300]);h1=get_param(pd1,'PortHandles');
pd2=makeProbe(mdl,'Measure_d2','ud2',[1320 525 1400 590]);h2=get_param(pd2,'PortHandles');
% ud is independently measured across the load; id follows exact resistor law.
pud=makeProbe(mdl,'Measure_load','ud',[1210 390 1290 455]);hd=get_param(pud,'PortHandles');

% Scope signals are direct circuit measurements, normalized to Um for readability.
viewer=newSub(mdl,'Waveforms',[1460 340 1650 490]);
scope=add_block('simulink/Sinks/Scope',[viewer '/Scope_voltage'], ...
    'NumInputPorts','3','Position',[435 135 500 265]);
sc=get_param(scope,'ScopeConfiguration');sc.TimeSpan='0.04';sc.ShowLegend=true;
for j=1:3
    names={'uVT1','ud1','ua'};name=names{j};y=105+(j-1)*80;
    f=add_block('simulink/Signal Routing/From',[viewer '/' name '_from'], ...
        'GotoTag',name,'Position',[55 y 165 y+30]);
    g=add_block('simulink/Math Operations/Gain',[viewer '/' name '_over_Um'], ...
        'Gain','1/Um','Position',[245 y 315 y+30]);
    a=get_param(f,'PortHandles');b=get_param(g,'PortHandles');c=get_param(scope,'PortHandles');
    add_line(viewer,a.Outport(1),b.Inport(1),'autorouting','on');
    ln=add_line(viewer,b.Outport(1),c.Inport(j),'autorouting','on');
    set_param(ln,'Name',[name '/Um']);
end
mask=Simulink.Mask.create(viewer);mask.IconUnits='normalized';
mask.Display='color(''blue'');plot([0.16 0.32 0.47 0.48 0.66 0.81],[0.69 0.69 0.5 0.84 0.64 0.64]);text(0.15,0.38,''电压示波器'');text(0.13,0.2,''uVT1 · ud1 · ua'');';
set_param(viewer,'ShowName','off','BackgroundColor','cyan', ...
    'OpenFcn','open_system([gcb ''/Scope_voltage'']);');
% Manually route the physical buses after querying the actual connector locations.
routeMain(mdl,columns,ups,downs,cells,src,r,pd1,pd2,pud,ref,sol);

note(mdl,'三相全控桥 · 电阻负载 · α = 90°',[75 20 950 65],22);
note(mdl,'上桥臂：VT1 / VT3 / VT5；下桥臂：VT4 / VT6 / VT2',[370 85 1050 120],13);
note(mdl,'每个 VT 内含真实晶闸管、RC 吸收及电压/电流探头；双击可展开。',[340 125 1175 165],12);
note(mdl,'d1：直流正端',[920 190 1160 225],14);
note(mdl,'d2：直流负端',[920 590 1160 625],14);
note(mdl,'N：电源中性点参考；d1、d2 均未接地',[180 680 870 720],12);
note(mdl,sprintf('双击打开示波器\nuVT1、ud1、ua\n按相电压峰值 Um 归一化'),[1460 230 1660 310],12);
note(mdl,'R 负载',[1090 465 1220 500],13);
for k=1:3,note(mdl,['相 ' char('a'+k-1)],[columns(k)-45 385 columns(k)+40 418],13);end
set_param(mdl,'ZoomFactor','FitSystem');
save_system(mdl,fullfile(root,[mdl '.slx']));
print(['-s' mdl],'-dpng','-r180',fullfile(outdir,'clear_bridge_circuit.png'));
print(['-s' mdl '/VT1'],'-dpng','-r160',fullfile(outdir,'clear_VT1_inside.png'));
if ~doVerify,fprintf('CLEAR_MODEL_LAYOUT_READY\n');diary off;return;end
fprintf('RUN clear circuit verification\n');s=sim(mdl);
names={'ua','ub','uc','ud1','ud2','ud','uVT1','iVT1','iVT2','iVT3','iVT4','iVT5','iVT6'};
ts=s.get('uVT1');t=ts.Time(:);data=struct('t',t);
for j=1:numel(names)
    z=s.get(names{j});data.(names{j})=interp1(z.Time,squeeze(z.Data),t,'linear');
end
data.id=data.ud/p.Rload;
T=struct2table(data);writetable(T(t>=.08,:),fullfile(outdir,'clear_model_sensor_data.csv'));
oldData=readtable(fullfile(outdir,'refined_dual.csv'));
phase=mod(18000*t,30);valid=t>.08 & min(phase,30-phase)>3;
diff=data.uVT1(valid)-interp1(oldData.t,oldData.uVT1,t(valid));
kvl=max(abs(data.uVT1-data.ua+data.ud1));err=max(abs(diff));
fprintf('CLEAR_MODEL KVL residual=%g V; reference difference away from edges=%g V\n',kvl,err);
assert(kvl<1e-5 && err<.1,'New layout changed the measured voltage.');
v=struct('referenceDifferenceAwayFromEdges',err,'KVL',kvl,'simulated',true);
fid=fopen(fullfile(outdir,'clear_model_verification.json'),'w');fprintf(fid,'%s',jsonencode(v,PrettyPrint=true));fclose(fid);
save(fullfile(outdir,'clear_model_results.mat'),'data','p','-v7.3');
save_system(mdl,fullfile(root,[mdl '.slx']));
fprintf('CLEAR_MODEL_OK\n');diary off;
end

function b=newSub(m,name,pos)
b=[m '/' name];
add_block('simulink/Ports & Subsystems/Subsystem',b,'Position',pos);
Simulink.SubSystem.deleteContents(b);
end
function port=conn(m,name,side,n,pos)
b=add_block('nesl_utility/Connection Port',[m '/' name], ...
    'Side',side,'Port',num2str(n),'Position',pos);h=get_param(b,'PortHandles');
port=[h.LConn h.RConn];port=port(1);
end
function wire(m,a,b)
add_line(m,a,b,'autorouting','on');
end
function logSignal(m,ph,name,unit,pos)
c=add_block('nesl_utility/PS-Simulink Converter',[m '/' name '_PS'], ...
    'Unit',unit,'Position',[pos(1) pos(2) pos(1)+35 pos(2)+25]);h=get_param(c,'PortHandles');
wire(m,ph,h.LConn(1));
w=add_block('simulink/Sinks/To Workspace',[m '/' name '_log'], ...
    'VariableName',name,'SaveFormat','Timeseries','Position',[pos(1)+110 pos(2) pos(1)+210 pos(2)+25]);q=get_param(w,'PortHandles');
add_line(m,h.Outport(1),q.Inport(1),'autorouting','on');
g=add_block('simulink/Signal Routing/Goto',[m '/' name '_tag'], ...
    'GotoTag',name,'TagVisibility','global', ...
    'Position',[pos(1)+110 pos(2)+45 pos(1)+230 pos(2)+70]);q=get_param(g,'PortHandles');
add_line(m,h.Outport(1),q.Inport(1),'autorouting','on');
end
function probe(m,a,b,name,pos)
v=add_block('fl_lib/Electrical/Electrical Sensors/Voltage Sensor',[m '/' name '_sensor'], ...
    'Position',[pos(1) pos(2) pos(1)+45 pos(2)+30]);h=get_param(v,'PortHandles');
wire(m,a,h.LConn(1));wire(m,b,h.RConn(2));
logSignal(m,h.RConn(1),name,'V',[pos(1)+85 pos(2)]);
end
function handle=makeSCR(m,old,v,pos)
b=newSub(m,sprintf('VT%d',v),pos);handle=get_param(b,'Handle');
A=conn(b,'A','Left',1,[35 205 55 225]);K=conn(b,'K','Right',2,[580 205 600 225]);
scr=add_block(sprintf('%s/VT%d',old,v),[b '/Thyristor'], ...
    'Position',[345 150 395 230]);h=get_param(scr,'PortHandles');
i=add_block('fl_lib/Electrical/Electrical Sensors/Current Sensor',[b '/I_SCR'], ...
    'Position',[160 150 205 195]);q=get_param(i,'PortHandles');
wire(b,A,q.LConn(1));wire(b,q.RConn(2),h.RConn(1));wire(b,h.RConn(2),K);
logSignal(b,q.RConn(1),sprintf('iVT%d',v),'A',[620 95]);
g=add_block('simulink/Signal Routing/From',[b '/Gate'], ...
    'GotoTag',sprintf('gate_VT%d',v),'Position',[185 40 270 65]);gg=get_param(g,'PortHandles');
c=add_block(sprintf('%s/GatePS_VT%d',old,v),[b '/Gate_PS'], ...
    'Position',[310 40 345 65]);cc=get_param(c,'PortHandles');
add_line(b,gg.Outport(1),cc.Inport(1),'autorouting','on');wire(b,cc.RConn(1),h.LConn(1));
r=add_block(sprintf('%s/Snubber_R%d',old,v),[b '/R_snubber'], ...
    'Position',[180 325 235 355]);rh=get_param(r,'PortHandles');
c=add_block(sprintf('%s/Snubber_C%d',old,v),[b '/C_snubber'], ...
    'Position',[365 325 415 355]);ch=get_param(c,'PortHandles');
wire(b,A,rh.LConn(1));wire(b,rh.RConn(1),ch.LConn(1));wire(b,ch.RConn(1),K);
probe(b,A,K,sprintf('uVT%d',v),[475 390]);
note(b,'真实 SCR 主支路',[240 105 480 135],13);
note(b,'串联 RC 吸收支路',[230 285 470 315],13);
note(b,'探头直接跨 A、K；电流探头只测 SCR 主支路',[105 510 800 550],12);
mask=Simulink.Mask.create(b);
mask.IconUnits='normalized';
mask.Display=scr_icon_display(v);
set_param(b,'Orientation','up','BackgroundColor','white','ShowName','off','FontSize',12, ...
    'OpenFcn','open_system(gcb,''force'');');
end
function b=makeProbe(m,name,var,pos)
b=newSub(m,name,pos);
A=conn(b,'Plus','Left',1,[30 120 50 140]);N=conn(b,'Minus','Right',2,[530 120 550 140]);
probe(b,A,N,var,[180 100]);
mask=Simulink.Mask.create(b);mask.IconUnits='normalized';
mask.Display=sprintf('color(''blue'');text(0.4,0.6,''V'');text(0.27,0.25,''%s'');port_label(''LConn'',1,''+'');port_label(''RConn'',1,''−'');',var);
set_param(b,'ShowName','off','FontSize',12);
end
function note(m,s,pos,sz)
n=Simulink.Annotation(m,s);n.Position=pos;n.FontSize=sz;n.Interpreter='off';
end
function routeMain(m,cols,ups,downs,cells,src,r,pd1,pd2,pud,ref,sol)
% Create main electrical lines once, then set simple bus/phase geometry.
rh=get_param(r,'PortHandles');d1=rh.LConn(1);d2=rh.RConn(1);
sh=get_param(src,'PortHandles');rf=get_param(ref,'PortHandles');N=rf.LConn(1);
so=get_param(sol,'PortHandles');
draw(m,sh.LConn(1),N,[40 get_param(sh.LConn(1),'Position')*[0;1];40 620]);
draw(m,N,so.RConn(1),[]);
hu=get_param(cells(ups(1)),'PortHandles');
draw(m,hu.RConn(1),d1,[get_param(hu.RConn(1),'Position')*[1;0] 205;1155 205]);
hl=get_param(cells(downs(1)),'PortHandles');
draw(m,hl.LConn(1),d2,[get_param(hl.LConn(1),'Position')*[1;0] 630;1155 630]);
for k=1:3
    hu=get_param(cells(ups(k)),'PortHandles');hl=get_param(cells(downs(k)),'PortHandles');
    ap=get_param(hu.LConn(1),'Position');kp=get_param(hl.RConn(1),'Position');
    y=390+(k-2)*32;
    draw(m,sh.RConn(k),hu.LConn(1),[300 y;ap(1) y]);
    draw(m,hu.LConn(1),hl.RConn(1),[ap(1) y;kp(1) y]);
    if k>1
        z=get_param(hu.RConn(1),'Position');draw(m,hu.RConn(1),d1,[z(1) 205;1155 205]);
        z=get_param(hl.LConn(1),'Position');draw(m,hl.LConn(1),d2,[z(1) 630;1155 630]);
    end
end
h=get_param(pd1,'PortHandles');draw(m,d1,h.LConn(1),[1155 205;1280 205;1280 268]);draw(m,N,h.RConn(1),[150 740;1420 740;1420 268]);
h=get_param(pd2,'PortHandles');draw(m,d2,h.LConn(1),[1155 630;1280 630;1280 558]);draw(m,N,h.RConn(1),[150 740;1420 740;1420 558]);
h=get_param(pud,'PortHandles');draw(m,d1,h.LConn(1),[1195 360;1195 423]);draw(m,d2,h.RConn(1),[1305 470;1305 423]);
end
function draw(m,a,b,mids)
ln=add_line(m,a,b,'autorouting','on');
if ~isempty(mids)
    pa=get_param(a,'Position');pb=get_param(b,'Position');
    try,set_param(ln,'Points',[pa;mids;pb]);catch,end
end
end
