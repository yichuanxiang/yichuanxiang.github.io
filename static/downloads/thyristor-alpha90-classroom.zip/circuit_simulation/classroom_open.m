function classroom_open(runSimulation)
% Portable classroom entry. Default opens the saved circuit without recomputing.
if nargin < 1, runSimulation = false; end
root = fileparts(mfilename('fullpath'));
addpath(root); cd(root);
mdl = 'thyristor_bridge_R_alpha90_clear';
open_system(fullfile(root,[mdl '.slx']));
set_param(mdl,'ZoomFactor','FitSystem');
if runSimulation
    result = sim(mdl);
    assignin('base','clearCircuitOutput',result);
    open_system([mdl '/Waveforms/Scope_voltage']);
end
end
