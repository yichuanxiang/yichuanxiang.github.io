function results=run_alpha90_circuit
% Simscape native six-SCR circuit. No imposed d1/d2 voltage and no waveform stitching.
root=fileparts(mfilename('fullpath')); outdir=fullfile(root,'output');
if ~exist(outdir,'dir'),mkdir(outdir);end
diary(fullfile(outdir,'circuit_run.log'));
mdl='thyristor_bridge_R_alpha90';
if bdIsLoaded(mdl),close_system(mdl,0);end
load_system('ee_lib');load_system('fl_lib');load_system('nesl_utility');
lib=find_system('ee_lib','LookUnderMasks','all','FollowLinks','off', ...
    'RegExp','on','Name','Thyristor.*');
scrlib=lib{contains(lib,'Piecewise')};
new_system(mdl);
set_param(mdl,'Solver','ode23t','SolverType','Variable-step', ...
    'MaxStep','5e-6','RelTol','1e-6','AbsTol','1e-7','StopTime','0.12', ...
    'ReturnWorkspaceOutputs','on','SaveTime','on','SaveOutput','off');

p=struct('UphaseRMS',220,'f',50,'Rload',10,'alpha',90, ...
    'Ron',0.001,'Vf',0.8,'Goff',1e-7,'Ih',0.1, ...
    'Rsnub',500,'Csnub',250e-9,'gateAmplitude',10,'pulseWidth',5,'stop',0.12);
ref=add_block('fl_lib/Electrical/Electrical Elements/Electrical Reference', ...
    [mdl '/Neutral_reference'],'Position',[100 550 125 575]);
rp=get_param(ref,'PortHandles');neutral=rp.LConn(1);
sol=add_block('nesl_utility/Solver Configuration',[mdl '/Solver'], ...
    'Position',[20 530 80 570]);sp=get_param(sol,'PortHandles');
wire(mdl,neutral,sp.RConn(1));
phase=zeros(1,3);
for j=1:3
    b=add_block('fl_lib/Electrical/Electrical Sources/AC Voltage Source', ...
        [mdl '/Source_' char('a'+j-1)],'Position',[150 220+j*85 185 265+j*85], ...
        'amp',num2str(sqrt(2)*p.UphaseRMS,16),'frequency','50', ...
        'shift',num2str(-(j-1)*120));
    q=get_param(b,'PortHandles');phase(j)=q.LConn(1);wire(mdl,q.RConn(1),neutral);
end
load=add_block('fl_lib/Electrical/Electrical Elements/Resistor', ...
    [mdl '/R_load'],'Position',[1100 285 1155 325],'R','10');
lph=get_param(load,'PortHandles'); d1=lph.LConn(1);d2=lph.RConn(1);
% Source phase order: VT1=a, VT2=c, VT3=b, VT4=a, VT5=c, VT6=b.
phaseIdx=[1 3 2 1 3 2]; xpos=[420 860 640 420 860 640];
for v=1:6
    upper=mod(v,2)==1; yy=150+260*(~upper); xx=xpos(v);
    scr=add_block(scrlib,sprintf('%s/VT%d',mdl,v), ...
        'Position',[xx yy xx+50 yy+75], ...
        'Ron',num2str(p.Ron),'Vf',num2str(p.Vf),'Goff',num2str(p.Goff), ...
        'Ih',num2str(p.Ih),'Vgt','6');
    ph=get_param(scr,'PortHandles');
    % Native piecewise SCR: LConn1=gate PS, RConn1=anode, RConn2=cathode.
    sens=add_block('fl_lib/Electrical/Electrical Sensors/Current Sensor', ...
        sprintf('%s/I_VT%d_sensor',mdl,v),'Position',[xx+85 yy+15 xx+135 yy+50]);
    cp=get_param(sens,'PortHandles');
    wire(mdl,cp.RConn(2),ph.RConn(1));
    if upper
        anode=phase(phaseIdx(v));cathode=d1;
    else
        anode=d2;cathode=phase(phaseIdx(v));
    end
    wire(mdl,anode,cp.LConn(1));wire(mdl,ph.RConn(2),cathode);
    logPS(mdl,cp.RConn(1),sprintf('iVT%d',v),'A',[1420 20+v*45]);
    r=add_block('fl_lib/Electrical/Electrical Elements/Resistor', ...
        sprintf('%s/Snubber_R%d',mdl,v),'R',num2str(p.Rsnub), ...
        'Position',[xx+95 yy+65 xx+140 yy+95]);
    c=add_block('fl_lib/Electrical/Electrical Elements/Capacitor', ...
        sprintf('%s/Snubber_C%d',mdl,v),'c',num2str(p.Csnub), ...
        'Position',[xx+160 yy+65 xx+205 yy+95],'vc_specify','off');
    rh=get_param(r,'PortHandles');ch=get_param(c,'PortHandles');
    wire(mdl,anode,rh.LConn(1));wire(mdl,rh.RConn(1),ch.LConn(1));
    wire(mdl,ch.RConn(1),cathode);
    g=add_block('simulink/Sources/From Workspace',sprintf('%s/Gate_VT%d',mdl,v), ...
        'VariableName',sprintf('gateVT%d',v),'Interpolate','off', ...
        'OutputAfterFinalValue','Holding final value', ...
        'Position',[xx-160 yy+10 xx-90 yy+35]);
    conv=add_block('nesl_utility/Simulink-PS Converter',sprintf('%s/GatePS_VT%d',mdl,v), ...
        'Unit','V','Position',[xx-65 yy+10 xx-30 yy+35], ...
        'FilteringAndDerivatives','provide','UdotUserProvided','0');
    gh=get_param(g,'PortHandles');qh=get_param(conv,'PortHandles');
    add_line(mdl,gh.Outport(1),qh.Inport(1),'autorouting','on');
    wire(mdl,qh.RConn(1),ph.LConn(1));
    gw=add_block('simulink/Sinks/To Workspace',sprintf('%s/gVT%d_log',mdl,v), ...
        'VariableName',sprintf('gVT%d',v),'SaveFormat','Timeseries', ...
        'Position',[1610 20+v*45 1690 45+v*45]);
    gwp=get_param(gw,'PortHandles');
    add_line(mdl,gh.Outport(1),gwp.Inport(1),'autorouting','on');
end
voltageLog(mdl,phase(1),neutral,'ua',[1230 350]);
voltageLog(mdl,phase(2),neutral,'ub',[1230 395]);
voltageLog(mdl,phase(3),neutral,'uc',[1230 440]);
voltageLog(mdl,d1,neutral,'ud1',[1230 485]);
voltageLog(mdl,d2,neutral,'ud2',[1230 530]);
voltageLog(mdl,d1,d2,'ud',[1230 575]);
voltageLog(mdl,phase(1),d1,'uVT1',[1230 620]);
note=Simulink.Annotation(mdl, sprintf(['Three-phase fully controlled bridge | R load | alpha = 90 deg\n' ...
    'VT1/3/5: a/b/c upper group; VT4/6/2: a/b/c lower group\n' ...
    'Only source neutral is grounded. d1 and d2 are solved circuit nodes.\n' ...
    'Six native SCRs: Vf=0.8 V, Ron=1 mOhm, Ih=0.1 A, Goff=1e-7 S\n' ...
    'Six RC snubbers: R=500 Ohm, C=250 nF; dual 5-degree gate pulses.']));
note.Position=[20 10 950 110];
gatesFile=fullfile(root,'gate_inputs.mat');
set_param(mdl,'InitFcn',"load(fullfile(fileparts(get_param(bdroot,'FileName')),'gate_inputs.mat'));Um=sqrt(2)*220;");
set_param(mdl,'ZoomFactor','FitSystem');
save_system(mdl,fullfile(root,[mdl '.slx']));

% First run uses an actual finite leakage conductance and finite snubber capacitors.
gates=makeGates(p,'double');assignGates(gates,gatesFile);
fprintf('RUN baseline_dual: native circuit, Ih=%g A, Goff=%g S, RC=%g/%g\n', ...
    p.Ih,p.Goff,p.Rsnub,p.Csnub);
s=sim(mdl);results.baseline=collect(s,p,'dual');
save(fullfile(outdir,'baseline_dual.mat'),'-struct','results','baseline','-v7.3');
writeResults(results.baseline,outdir,'baseline_dual');
fprintf('BASELINE_OK samples=%d\n',numel(results.baseline.t));

% Gate-drive comparison. The circuit, sensors and device parameters remain identical.
assignGates(makeGates(p,'wide'),gatesFile);
fprintf('RUN wide_gate: 120-degree gate pulses\n');
s=sim(mdl);results.wide=collect(s,p,'wide');
writeResults(results.wide,outdir,'wide_gate');

% Check the concrete remaining modeling risk: snubber capacitance affects the floating nodes.
pSmall=p;pSmall.Csnub=p.Csnub/10;
for v=1:6,set_param(sprintf('%s/Snubber_C%d',mdl,v),'c',num2str(pSmall.Csnub));end
assignGates(makeGates(p,'double'),gatesFile);
fprintf('RUN small_cap: Csnub=%g F\n',pSmall.Csnub);
s=sim(mdl);results.smallcap=collect(s,pSmall,'dual');
writeResults(results.smallcap,outdir,'small_cap');

% A second solve with smaller steps checks that the reported shape is not solver discretization.
for v=1:6,set_param(sprintf('%s/Snubber_C%d',mdl,v),'c',num2str(p.Csnub));end
set_param(mdl,'MaxStep','2.5e-6','RelTol','3e-7','AbsTol','3e-8');
fprintf('RUN refined_dual: max step 2.5 us\n');
s=sim(mdl);results.refined=collect(s,p,'dual');
writeResults(results.refined,outdir,'refined_dual');
save_system(mdl,fullfile(root,[mdl '.slx']));
verifyResults(results,outdir);
save(fullfile(outdir,'circuit_results.mat'),'results','p','-v7.3');
close_system(mdl,0);diary off;
end

function wire(m,a,b)
add_line(m,a,b,'autorouting','on');
end

function logPS(m,port,name,unit,pos)
c=add_block('nesl_utility/PS-Simulink Converter',[m '/' name '_PS'], ...
    'Unit',unit,'Position',[pos(1) pos(2) pos(1)+35 pos(2)+25]);
w=add_block('simulink/Sinks/To Workspace',[m '/' name '_log'], ...
    'VariableName',name,'SaveFormat','Timeseries', ...
    'Position',[pos(1)+65 pos(2) pos(1)+145 pos(2)+25]);
ch=get_param(c,'PortHandles');wh=get_param(w,'PortHandles');
wire(m,port,ch.LConn(1));add_line(m,ch.Outport(1),wh.Inport(1),'autorouting','on');
end

function voltageLog(m,plus,minus,name,pos)
b=add_block('fl_lib/Electrical/Electrical Sensors/Voltage Sensor',[m '/' name '_sensor'], ...
    'Position',[pos(1) pos(2) pos(1)+45 pos(2)+30]);
h=get_param(b,'PortHandles');
wire(m,plus,h.LConn(1));wire(m,minus,h.RConn(2));
logPS(m,h.RConn(1),name,'V',[pos(1)+80 pos(2)]);
end

function gates=makeGates(p,mode)
angles=[];fire=30+p.alpha+(0:5)*60;
for c=-1:ceil(p.stop*p.f)
    for k=1:6
        if strcmp(mode,'double'),starts=fire(k)+[0 60];width=p.pulseWidth;
        else,starts=fire(k);width=120;end
        angles=[angles,starts+360*c,starts+width+360*c]; %#ok<AGROW>
    end
end
theta=unique([0,angles(angles>=0 & angles<=360*p.f*p.stop),360*p.f*p.stop]);
theta=round(theta*1e9)/1e9;t=theta(:)/(360*p.f);
for k=1:6
    d=mod(round((theta-fire(k))*1e9)/1e9,360);
    if strcmp(mode,'double'),on=(d<p.pulseWidth)|(mod(d-60,360)<p.pulseWidth);
    else,on=d<120;end
    gates.(sprintf('gateVT%d',k))=timeseries(p.gateAmplitude*double(on(:)),t);
end
end

function assignGates(gates,path)
save(path,'-struct','gates');
names=fieldnames(gates);
for j=1:numel(names),assignin('base',names{j},gates.(names{j}));end
end

function r=collect(s,p,mode)
names={'ua','ub','uc','ud1','ud2','ud','uVT1','iVT1','iVT2','iVT3','iVT4','iVT5','iVT6', ...
    'gVT1','gVT2','gVT3','gVT4','gVT5','gVT6'};
ts=s.get('uVT1');r.t=ts.Time(:);
for j=1:numel(names)
    x=s.get(names{j});r.(names{j})=interp1(x.Time,squeeze(x.Data),r.t,'linear');
end
r.id=r.ud/p.Rload;r.params=p;r.gateMode=mode;
end

function writeResults(r,outdir,name)
q=r.t>=r.params.stop-2/r.params.f;
T=table(r.t(q),r.ua(q),r.ub(q),r.uc(q),r.ud1(q),r.ud2(q),r.ud(q), ...
    r.uVT1(q),r.id(q),r.iVT1(q),r.iVT2(q),r.iVT3(q),r.iVT4(q),r.iVT5(q),r.iVT6(q), ...
    r.gVT1(q),r.gVT2(q),r.gVT3(q),r.gVT4(q),r.gVT5(q),r.gVT6(q), ...
    'VariableNames',{'t','ua','ub','uc','ud1','ud2','ud','uVT1','id', ...
    'iVT1','iVT2','iVT3','iVT4','iVT5','iVT6','gVT1','gVT2','gVT3','gVT4','gVT5','gVT6'});
writetable(T,fullfile(outdir,[name '.csv']));
fprintf('KVL error uVT1-(ua-ud1): %.3g V\n',max(abs(r.uVT1-r.ua+r.ud1)));
end

function verifyResults(results,outdir)
names=fieldnames(results);summary=struct;
for j=1:numel(names)
    r=results.(names{j});T=1/r.params.f;t0=r.params.stop-T;
    tq=(t0:1e-6:r.params.stop)';
    v=interp1(r.t,r.uVT1,tq);i=interp1(r.t,r.id,tq);
    summary.(names{j}).Ud=trapz(tq,interp1(r.t,r.ud,tq))/T;
    summary.(names{j}).Id=trapz(tq,i)/T;
    summary.(names{j}).Umax=max(v);summary.(names{j}).Umin=min(v);
    summary.(names{j}).KVL=max(abs(r.uVT1-r.ua+r.ud1));
    theta=mod(tq*r.params.f*360,360);
    eventDistance=min(mod(theta,30),30-mod(theta,30));
    stable=eventDistance>3;
    prev=interp1(r.t,r.uVT1,tq-T);
    summary.(names{j}).periodicMax= max(abs(v(stable)-prev(stable)));
end
tq=(0.1:1e-6:0.12)';theta=mod(tq*18000,360);
stable=min(mod(theta,30),30-mod(theta,30))>3;
vb=interp1(results.baseline.t,results.baseline.uVT1,tq);
vr=interp1(results.refined.t,results.refined.uVT1,tq);
summary.refinementMaxAwayFromEdges=max(abs(vb(stable)-vr(stable)));
summary.refinementRMSAwayFromEdges=sqrt(mean((vb(stable)-vr(stable)).^2));
gd=interp1(results.baseline.t,results.baseline.gVT1,tq,'previous');
gw=interp1(results.wide.t,results.wide.gVT1,tq,'previous');
summary.deliveredGateDifference=max(abs(gd-gw));
vw=interp1(results.wide.t,results.wide.uVT1,tq);
summary.wideVersusDualVoltageMax=max(abs(vw-vb));
assert(summary.deliveredGateDifference>9,'Gate comparison did not deliver different inputs.');
expected=[1 6;1 2;3 2;3 4;5 4;5 6];
for j=1:6
    tp=0.08+(135+(j-1)*60)/18000;
    iv=zeros(1,6);
    for k=1:6,iv(k)=interp1(results.refined.t,results.refined.(sprintf('iVT%d',k)),tp);end
    active=find(iv>1);
    assert(isequal(sort(active),sort(expected(j,:))),'Conduction pair or phase sequence mismatch.');
end
fprintf('REFINEMENT max away from edges = %.6g V\n',summary.refinementMaxAwayFromEdges);
fprintf('PERIODICITY refined max away from edges = %.6g V\n',summary.refined.periodicMax);
assert(summary.refined.KVL<1e-5,'Voltage probe polarity mismatch.');
assert(summary.refinementMaxAwayFromEdges<0.5,'Step convergence not established.');
assert(summary.refined.periodicMax<0.5,'Steady periodic state not established.');
fid=fopen(fullfile(outdir,'verification.json'),'w');
fprintf(fid,'%s',jsonencode(summary,'PrettyPrint',true));fclose(fid);
end
