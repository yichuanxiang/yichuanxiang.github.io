% Open the already-simulated physical circuit in the MATLAB/Simulink desktop.
root=fileparts(mfilename('fullpath'));
cd(root);
diary(fullfile(root,'output','open_model.log'));
try
    mdl='thyristor_bridge_R_alpha90';
    open_system(fullfile(root,[mdl '.slx']));
    set_param(mdl,'ZoomFactor','FitSystem');
    print(['-s' mdl],'-dpng','-r150',fullfile(root,'output','bridge_circuit.png'));
    fid=fopen(fullfile(root,'output','model_opened.txt'),'w');
    fprintf(fid,'Opened %s at %s\n',get_param(mdl,'FileName'),datestr(now,31));
    fclose(fid);
    fprintf('MODEL_OPENED: %s\n',get_param(mdl,'FileName'));
catch ex
    fprintf(2,'%s\n',getReport(ex,'extended'));
end
diary off;
