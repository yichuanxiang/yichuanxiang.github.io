# 课件画法与实物管压

教师课件图3-26最上面的端电位波形，把全截止区间的 ud1、ud2 都画在零线上。按这幅图的电位约定补画 VT1 管压，该区间是 uVT1=ua。

图 `output/vt1_courseware_vs_externalRC.png` 上半部分是按此约定绘制的解析示意，不是新完成的无 RC 开关仿真。下半部分读取原有 `output/clear_model_sensor_data.csv`，对应六条额外外接 RC 的原模型。

纯电阻负载电流为零，只给出 ud1−ud2=0，不能单独推出 ud1=ud2=0。若六个截止器件完全开路，又没有任何电容、漏电、测量通路，公共电位没有唯一解。

一个能给出零公共电位的明确模型是：三相平衡，六管截止时都是相同的有限电导 G，不含任何电容。对两个直流节点列 KCL，可以得到 ud1=ud2=0。这个全截止等效网络已用 `output/model_checks/all_off_equal_leakage.slx` 核对，验证记录为同目录的 `all_off_equal_leakage_verification.json`。它不是完整门极切换仿真。

2026-09-30 新试验 `check_no_rc_switching.m` 从清晰版六管模型移除六条 RC，并明确设置相同 Goff=1e-5 S。该完整切换试验仍未通过六支路截止方程检查，`output/model_checks/noRC_equalLeakage_verification.json` 的 passed=false。对应 `alpha90_noRC_equalLeakage.slx` 和 CSV 仅供诊断，不应作为已验证波形使用。先前 Goff=1e-7 S 的混合模型试验也未通过，已保留原诊断。

实物即使没有外接 RC，仍有器件寄生电容、截止漏电、接线和测量通路。原外接 RC 模型的半峰公共电位，不是指定实物的测量结果，也没有依据指定实物寄生参数建立。

课堂说明可以写成：按课件图的理想电位约定，全截止时 VT1 管压等于 ua；考虑实际寄生网络时，始终应从 uVT1=ua−ud1 计算。外接 RC 模型是另一种明确电路条件。

器件寄生电容的一级资料：ST AN4608 第20页。
https://www.st.com/resource/en/application_note/an4608-how-to-select-the-right-thyristor-scr-for-your-application-stmicroelectronics.pdf
