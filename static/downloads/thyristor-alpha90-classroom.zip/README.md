# 三相全控桥 α=90°：课堂演示包

## 先看网页，再看模型

1. 解压本 ZIP；双击根目录「课堂演示.html」。浏览器演示完全离线可用，不需要本机运行网站服务。
2. 拖动相位、播放一周期或逐段切换导通管对，电路图会同步标出导通、截止和主电流路径。网页示波器来自本包已经保存的传感器数据，浏览器没有运行 Simulink。
3. 打开 web/classroom/thyristor-alpha90/matlab-simulation.mp4 查看 MATLAB / Simulink 原生仿真录像：电路模型、Scope 实际求解至 0.12 秒和最终波形。三路依次为 uVT1/Um、ud1/Um、ua/Um；显示减速不改变电路参数。waveform-demo.mp4 是另存的网页动画录屏。
4. 要查看可编辑的真实电路，在 MATLAB 中将当前目录切到 circuit_simulation，运行 `classroom_open`；确认安装所需产品后，可按 Simulink 的运行按钮，或运行 `classroom_open(true)`。

## 两种曲线必须分清

- **课件零公共电位约定的解析示意**：α=90°、纯电阻负载，每对导通约 30°、随后全截止约 30°。全截止示意设 ud1=ud2=0，故 uVT1=ua。它是按课件图3-26电位约定补画的解析曲线；没有将它称为新验证的无 RC 门极切换仿真。
- **六条外接 RC 的已保存电路仿真**：六个原生分段线性 SCR，各并联一条外接串联 RC。网页数据由 clear_model_sensor_data.csv 的稳态周期提取。全截止段公共电位 ux 接近正负半峰值，uVT1=ua−ud1；该半峰近似只属于当前对称网络。
- 两者均不是实物测量。α=90°、零负载电流本身不能单独确定浮空直流端的公共电位；也不能把含 RC 模型的截止管压当作教师未画 RC 的原电路结果。

## 运行环境和模型参数

原模型已经在 MATLAB R2024b 中保存并运行；需要 MATLAB、Simulink、Simscape、Simscape Electrical。建议使用 R2024b 或更高版本。软件、许可证与教师完整课件均未包含在本包中。

相电压有效值 U=220 V，50 Hz，峰值 Um=√2U；负载 10 Ω；α=90°。
SCR：Vf=0.8 V、Ron=1 mΩ、Goff=10⁻⁷ S、Ih=0.1 A。
每只 SCR 外接串联吸收 RC：500 Ω、250 nF。门极 10 V、宽度 5° 的双窄脉冲，两脉冲相隔 60°。
上桥臂 VT1/VT3/VT5 对应 a/b/c；下桥臂 VT4/VT6/VT2 对应 a/b/c。
导通顺序：1/6 → 1/2 → 3/2 → 3/4 → 5/4 → 5/6。

## 内容和重现

- circuit_simulation/：清晰版与原版可编辑 .slx、gate_inputs.mat、必要 MATLAB/Python 脚本。
- circuit_simulation/output/：两份原 CSV、成功验证 JSON、波形和电路图片。CSV 未改写。
- docs/：课堂讲稿、当前模型适用条件和课件/RC 区别。
- web/：离线交互网页，含归一化电压数据、同步电路示意、本地图片和 MP4 演示视频。
- MANIFEST.json、SHA256SUMS.txt：文件清单、来源哈希与打包后完整性。

两份 .slx 下载副本仅改 InitFcn：从模型文件自己的目录加载门极 MAT，而非开发机器的绝对路径；电路与器件配置保持原样。build_clear_alpha90.m 的课堂副本用同一套明确参数替代读取大体积开发结果 MAT，并使用便携 InitFcn。run_alpha90_circuit.m 同样改为便携 InitFcn。原项目文件没有被改动。

`run_alpha90_circuit` 会重新构建并运行多个 RC/门极工况，耗时多于课堂打开现存清晰模型；无需上课时临时重算。`build_clear_alpha90(false)` 可从原模型重建清晰版布局。

已有验证：KVL 最大残差约 5.7×10⁻¹⁴ V；缩小步长后、远离开关边沿的差约 2.46×10⁻⁴ V；相邻稳态周期同一区域差约 4.20×10⁻¹⁰ V。应结合 output 中的 JSON 阅读适用范围。

打包时做了 ZIP 完整性、脚本依赖与便携路径检查，没有在另一台计算机上重新运行 MATLAB。因此这里只说明离线路径已处理，不能替代对目标机器产品安装情况和运行结果的确认。

失败的去 RC 开关实验、临时日志、slprj、.slxc 缓存及教师课件原文均未打包。
