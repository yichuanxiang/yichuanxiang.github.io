# 两种 Buck：模型、原始数据和校验记录

本包保留已经实际运行过的四个 Simscape 模型，以及对应传感器数据。网页只展示保存的截图和数据，并不在浏览器里重新运行 MATLAB。

## 打开模型

使用 MATLAB R2024b、Simulink、Simscape 及相应电气库。打开 RLE 或 LC 文件夹下的 .slx，点击运行，再双击模型右侧“波形”。参数已保存在各模型工作区，不依赖本机绝对路径或外部 MAT 文件。

- RLE/buck_courseware_clear.slx：L-R-EM 负载，连续。
- RLE/buck_courseware_DCM_clear.slx：L-R-EM 负载，断续。
- LC/buck_LC_CCM.slx：LC 滤波，连续。
- LC/buck_LC_DCM.slx：LC 滤波，断续。

RLE 的连续/断续只改变 L：10 mH / 1 mH；Ed=100 V、EM=30 V、R=5 Ω、T=1 ms、d=1/2。
LC 的连续/断续只改变 R：10 Ω / 100 Ω；Ed=100 V、L=10 mH、C=1000 μF、T=1 ms、d=1/2。
这些是本次自选示例参数，不是课件给定参数。两类电路的对比不是同参数单变量实验。

## 文件

data/ 下为完整起动过程的原始 CSV（refined 为断续工况的细化步长运行）。verification/ 下为元件参数及校验 JSON。images/ 下为原生电路、原生示波器截图、符号标注图。

符号图直接使用原始传感器曲线，各行幅值独立缩放；LC 输出纹波被放大显示。RLE 的 uo 测整个 L-R-EM 负载，LC 的 uo 测并联 C、R 两端，us 是开关节点。

RLE 断流时 uo≈EM、uVT≈Ed-EM；LC 断流时 iL≈0，而 iR>0、iC≈-iR，由电容继续供电。

校验包括 KCL/KVL、稳态转换比及电感/电容方程；断续工况额外核对归零区间和细化步长。LC 电感积分按稳定导通段独立核对，跨开关边沿的原始梯形积分诊断保留在 JSON。

模型属于功能仿真，没有拟合实物器件的开关速度、反向恢复、非线性结电容和线路杂散参数，不用于断言实物开关尖峰或损耗。

网页：https://yichuanxiang.github.io/classroom/buck-comparison/
文章：https://yichuanxiang.github.io/posts/buck-simulation-comparison/
